﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CentralitaHerencia;

namespace FormCentralTelefonica
{
    public partial class FrmMostrar : Form
    {
        Centralita centralita;
        TipoLlamada tipoLlamada;
        
        public FrmMostrar(Centralita c)
        {
            InitializeComponent();
            this.centralita = c;
        }

        public TipoLlamada TipoDeLlamada
        {
            set
            {
                this.tipoLlamada = value;
            }
        }

        public void MostrarLlamadas(Centralita c, TipoLlamada tipoLlamada)
        {
            StringBuilder sbLlamadas = new StringBuilder();

            switch (tipoLlamada)
            {
                case TipoLlamada.Local:
                    sbLlamadas.AppendFormat("Llamadas Locales:\n");
                    sbLlamadas.AppendFormat("\tTotal facturado: ${0}\n", c.GananciasPorLocal);

                    foreach (Llamada auxLlamada in c.Llamadas)
                    {
                        if (auxLlamada is Local)
                        {
                            sbLlamadas.AppendLine(auxLlamada.ToString());
                        }
                    }
                    break;
                case TipoLlamada.Provincial:
                    sbLlamadas.AppendFormat("Llamadas Provinciales:\n");

                    foreach (Llamada auxLlamada in c.Llamadas)
                    {
                        if (auxLlamada is Provincial)
                        {
                            sbLlamadas.AppendLine(auxLlamada.ToString());
                        }
                    }
                    break;
                case TipoLlamada.Todas:
                    sbLlamadas.AppendFormat("Todas las llamadas:\n");
                    sbLlamadas.AppendFormat("\tTotal facturado: ${0}\n", c.GananciasPorTotal);
                    foreach (Llamada auxLlamada in c.Llamadas)
                    {
                        sbLlamadas.AppendLine(auxLlamada.ToString());
                    }
                    break;
            }

            rtbInfo.Text = sbLlamadas.ToString();
        }

        private void btnMostrar_Click(object sender, EventArgs e)
        {
            MostrarLlamadas(this.centralita, this.tipoLlamada);
        }
    }
}
