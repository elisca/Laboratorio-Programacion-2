﻿namespace FormCentralTelefonica
{
    partial class FrmLlamador
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gbPanel = new System.Windows.Forms.GroupBox();
            this.btnNro1 = new System.Windows.Forms.Button();
            this.btnNro2 = new System.Windows.Forms.Button();
            this.btnNro3 = new System.Windows.Forms.Button();
            this.btnNro4 = new System.Windows.Forms.Button();
            this.btnNro5 = new System.Windows.Forms.Button();
            this.btnNro6 = new System.Windows.Forms.Button();
            this.btnNro7 = new System.Windows.Forms.Button();
            this.btnNro8 = new System.Windows.Forms.Button();
            this.btnNro9 = new System.Windows.Forms.Button();
            this.btnNro0 = new System.Windows.Forms.Button();
            this.btnAst = new System.Windows.Forms.Button();
            this.btnNum = new System.Windows.Forms.Button();
            this.btnLlamar = new System.Windows.Forms.Button();
            this.btnLimpiar = new System.Windows.Forms.Button();
            this.btnSalir = new System.Windows.Forms.Button();
            this.txtNroDestino = new System.Windows.Forms.TextBox();
            this.txtNroOrigen = new System.Windows.Forms.TextBox();
            this.cmbFranja = new System.Windows.Forms.ComboBox();
            this.gbPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // gbPanel
            // 
            this.gbPanel.Controls.Add(this.btnNum);
            this.gbPanel.Controls.Add(this.btnAst);
            this.gbPanel.Controls.Add(this.btnNro0);
            this.gbPanel.Controls.Add(this.btnNro9);
            this.gbPanel.Controls.Add(this.btnNro8);
            this.gbPanel.Controls.Add(this.btnNro7);
            this.gbPanel.Controls.Add(this.btnNro6);
            this.gbPanel.Controls.Add(this.btnNro5);
            this.gbPanel.Controls.Add(this.btnNro4);
            this.gbPanel.Controls.Add(this.btnNro3);
            this.gbPanel.Controls.Add(this.btnNro2);
            this.gbPanel.Controls.Add(this.btnNro1);
            this.gbPanel.Location = new System.Drawing.Point(12, 50);
            this.gbPanel.Name = "gbPanel";
            this.gbPanel.Size = new System.Drawing.Size(168, 238);
            this.gbPanel.TabIndex = 0;
            this.gbPanel.TabStop = false;
            this.gbPanel.Text = "Panel";
            // 
            // btnNro1
            // 
            this.btnNro1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNro1.Location = new System.Drawing.Point(6, 19);
            this.btnNro1.Name = "btnNro1";
            this.btnNro1.Size = new System.Drawing.Size(48, 48);
            this.btnNro1.TabIndex = 0;
            this.btnNro1.Text = "1";
            this.btnNro1.UseVisualStyleBackColor = true;
            this.btnNro1.Click += new System.EventHandler(this.btnNro1_Click);
            // 
            // btnNro2
            // 
            this.btnNro2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNro2.Location = new System.Drawing.Point(60, 19);
            this.btnNro2.Name = "btnNro2";
            this.btnNro2.Size = new System.Drawing.Size(48, 48);
            this.btnNro2.TabIndex = 1;
            this.btnNro2.Text = "2";
            this.btnNro2.UseVisualStyleBackColor = true;
            this.btnNro2.Click += new System.EventHandler(this.btnNro2_Click);
            // 
            // btnNro3
            // 
            this.btnNro3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNro3.Location = new System.Drawing.Point(114, 19);
            this.btnNro3.Name = "btnNro3";
            this.btnNro3.Size = new System.Drawing.Size(48, 48);
            this.btnNro3.TabIndex = 2;
            this.btnNro3.Text = "3";
            this.btnNro3.UseVisualStyleBackColor = true;
            this.btnNro3.Click += new System.EventHandler(this.btnNro3_Click);
            // 
            // btnNro4
            // 
            this.btnNro4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNro4.Location = new System.Drawing.Point(6, 73);
            this.btnNro4.Name = "btnNro4";
            this.btnNro4.Size = new System.Drawing.Size(48, 48);
            this.btnNro4.TabIndex = 3;
            this.btnNro4.Text = "4";
            this.btnNro4.UseVisualStyleBackColor = true;
            this.btnNro4.Click += new System.EventHandler(this.btnNro4_Click);
            // 
            // btnNro5
            // 
            this.btnNro5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNro5.Location = new System.Drawing.Point(60, 73);
            this.btnNro5.Name = "btnNro5";
            this.btnNro5.Size = new System.Drawing.Size(48, 48);
            this.btnNro5.TabIndex = 4;
            this.btnNro5.Text = "5";
            this.btnNro5.UseVisualStyleBackColor = true;
            this.btnNro5.Click += new System.EventHandler(this.btnNro5_Click);
            // 
            // btnNro6
            // 
            this.btnNro6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNro6.Location = new System.Drawing.Point(114, 73);
            this.btnNro6.Name = "btnNro6";
            this.btnNro6.Size = new System.Drawing.Size(48, 48);
            this.btnNro6.TabIndex = 5;
            this.btnNro6.Text = "6";
            this.btnNro6.UseVisualStyleBackColor = true;
            this.btnNro6.Click += new System.EventHandler(this.btnNro6_Click);
            // 
            // btnNro7
            // 
            this.btnNro7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNro7.Location = new System.Drawing.Point(6, 127);
            this.btnNro7.Name = "btnNro7";
            this.btnNro7.Size = new System.Drawing.Size(48, 48);
            this.btnNro7.TabIndex = 6;
            this.btnNro7.Text = "7";
            this.btnNro7.UseVisualStyleBackColor = true;
            this.btnNro7.Click += new System.EventHandler(this.btnNro7_Click);
            // 
            // btnNro8
            // 
            this.btnNro8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNro8.Location = new System.Drawing.Point(60, 127);
            this.btnNro8.Name = "btnNro8";
            this.btnNro8.Size = new System.Drawing.Size(48, 48);
            this.btnNro8.TabIndex = 7;
            this.btnNro8.Text = "8";
            this.btnNro8.UseVisualStyleBackColor = true;
            this.btnNro8.Click += new System.EventHandler(this.btnNro8_Click);
            // 
            // btnNro9
            // 
            this.btnNro9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNro9.Location = new System.Drawing.Point(114, 127);
            this.btnNro9.Name = "btnNro9";
            this.btnNro9.Size = new System.Drawing.Size(48, 48);
            this.btnNro9.TabIndex = 8;
            this.btnNro9.Text = "9";
            this.btnNro9.UseVisualStyleBackColor = true;
            this.btnNro9.Click += new System.EventHandler(this.btnNro9_Click);
            // 
            // btnNro0
            // 
            this.btnNro0.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNro0.Location = new System.Drawing.Point(60, 181);
            this.btnNro0.Name = "btnNro0";
            this.btnNro0.Size = new System.Drawing.Size(48, 48);
            this.btnNro0.TabIndex = 9;
            this.btnNro0.Text = "0";
            this.btnNro0.UseVisualStyleBackColor = true;
            this.btnNro0.Click += new System.EventHandler(this.btnNro0_Click);
            // 
            // btnAst
            // 
            this.btnAst.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAst.Location = new System.Drawing.Point(6, 181);
            this.btnAst.Name = "btnAst";
            this.btnAst.Size = new System.Drawing.Size(48, 48);
            this.btnAst.TabIndex = 10;
            this.btnAst.Text = "*";
            this.btnAst.UseVisualStyleBackColor = true;
            this.btnAst.Click += new System.EventHandler(this.btnAst_Click);
            // 
            // btnNum
            // 
            this.btnNum.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNum.Location = new System.Drawing.Point(114, 181);
            this.btnNum.Name = "btnNum";
            this.btnNum.Size = new System.Drawing.Size(48, 48);
            this.btnNum.TabIndex = 11;
            this.btnNum.Text = "#";
            this.btnNum.UseVisualStyleBackColor = true;
            this.btnNum.Click += new System.EventHandler(this.btnNum_Click);
            // 
            // btnLlamar
            // 
            this.btnLlamar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLlamar.Location = new System.Drawing.Point(186, 69);
            this.btnLlamar.Name = "btnLlamar";
            this.btnLlamar.Size = new System.Drawing.Size(146, 48);
            this.btnLlamar.TabIndex = 1;
            this.btnLlamar.Text = "Llamar";
            this.btnLlamar.UseVisualStyleBackColor = true;
            this.btnLlamar.Click += new System.EventHandler(this.btnLlamar_Click);
            // 
            // btnLimpiar
            // 
            this.btnLimpiar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLimpiar.Location = new System.Drawing.Point(186, 123);
            this.btnLimpiar.Name = "btnLimpiar";
            this.btnLimpiar.Size = new System.Drawing.Size(146, 48);
            this.btnLimpiar.TabIndex = 2;
            this.btnLimpiar.Text = "Limpiar";
            this.btnLimpiar.UseVisualStyleBackColor = true;
            this.btnLimpiar.Click += new System.EventHandler(this.btnLimpiar_Click);
            // 
            // btnSalir
            // 
            this.btnSalir.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSalir.Location = new System.Drawing.Point(186, 231);
            this.btnSalir.Name = "btnSalir";
            this.btnSalir.Size = new System.Drawing.Size(146, 48);
            this.btnSalir.TabIndex = 3;
            this.btnSalir.Text = "Salir";
            this.btnSalir.UseVisualStyleBackColor = true;
            this.btnSalir.Click += new System.EventHandler(this.btnSalir_Click);
            // 
            // txtNroDestino
            // 
            this.txtNroDestino.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNroDestino.Location = new System.Drawing.Point(12, 12);
            this.txtNroDestino.Name = "txtNroDestino";
            this.txtNroDestino.ReadOnly = true;
            this.txtNroDestino.Size = new System.Drawing.Size(320, 31);
            this.txtNroDestino.TabIndex = 4;
            this.txtNroDestino.TextChanged += new System.EventHandler(this.txtNroDestino_TextChanged);
            // 
            // txtNroOrigen
            // 
            this.txtNroOrigen.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNroOrigen.Location = new System.Drawing.Point(186, 180);
            this.txtNroOrigen.Name = "txtNroOrigen";
            this.txtNroOrigen.Size = new System.Drawing.Size(146, 35);
            this.txtNroOrigen.TabIndex = 5;
            // 
            // cmbFranja
            // 
            this.cmbFranja.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbFranja.FormattingEnabled = true;
            this.cmbFranja.Location = new System.Drawing.Point(12, 294);
            this.cmbFranja.Name = "cmbFranja";
            this.cmbFranja.Size = new System.Drawing.Size(320, 37);
            this.cmbFranja.TabIndex = 6;
            this.cmbFranja.Text = "Franja";
            // 
            // FrmLlamador
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(343, 342);
            this.Controls.Add(this.cmbFranja);
            this.Controls.Add(this.txtNroOrigen);
            this.Controls.Add(this.txtNroDestino);
            this.Controls.Add(this.btnSalir);
            this.Controls.Add(this.btnLimpiar);
            this.Controls.Add(this.btnLlamar);
            this.Controls.Add(this.gbPanel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "FrmLlamador";
            this.Text = "Llamador";
            this.gbPanel.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox gbPanel;
        private System.Windows.Forms.Button btnNum;
        private System.Windows.Forms.Button btnAst;
        private System.Windows.Forms.Button btnNro0;
        private System.Windows.Forms.Button btnNro9;
        private System.Windows.Forms.Button btnNro8;
        private System.Windows.Forms.Button btnNro7;
        private System.Windows.Forms.Button btnNro6;
        private System.Windows.Forms.Button btnNro5;
        private System.Windows.Forms.Button btnNro4;
        private System.Windows.Forms.Button btnNro3;
        private System.Windows.Forms.Button btnNro2;
        private System.Windows.Forms.Button btnNro1;
        private System.Windows.Forms.Button btnLlamar;
        private System.Windows.Forms.Button btnLimpiar;
        private System.Windows.Forms.Button btnSalir;
        private System.Windows.Forms.TextBox txtNroDestino;
        private System.Windows.Forms.TextBox txtNroOrigen;
        private System.Windows.Forms.ComboBox cmbFranja;
    }
}