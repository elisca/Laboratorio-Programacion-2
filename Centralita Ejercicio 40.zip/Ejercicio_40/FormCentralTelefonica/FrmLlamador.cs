﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CentralitaHerencia;

namespace FormCentralTelefonica
{
    public partial class FrmLlamador : Form
    {
        Centralita centralita;
        Llamada llamada;

        public FrmLlamador(Centralita c)
        {
            InitializeComponent();
            this.centralita = c;
            Type type = typeof(Provincial.Franja);
            string[] franjas = Enum.GetNames(type);
            this.cmbFranja.Items.AddRange(franjas);
        }

        public Centralita CentralTelefonica
        {
            get
            {
                return this.centralita;
            }
        }

        private void btnNro1_Click(object sender, EventArgs e)
        {
            txtNroDestino.Text = txtNroDestino.Text + "1";
        }

        private void btnNro2_Click(object sender, EventArgs e)
        {
            txtNroDestino.Text = txtNroDestino.Text + "2";
        }

        private void btnNro3_Click(object sender, EventArgs e)
        {
            txtNroDestino.Text = txtNroDestino.Text + "3";
        }

        private void btnNro4_Click(object sender, EventArgs e)
        {
            txtNroDestino.Text = txtNroDestino.Text + "4";
        }

        private void btnNro5_Click(object sender, EventArgs e)
        {
            txtNroDestino.Text = txtNroDestino.Text + "5";
        }

        private void btnNro6_Click(object sender, EventArgs e)
        {
            txtNroDestino.Text = txtNroDestino.Text + "6";
        }

        private void btnNro7_Click(object sender, EventArgs e)
        {
            txtNroDestino.Text = txtNroDestino.Text + "7";
        }

        private void btnNro8_Click(object sender, EventArgs e)
        {
            txtNroDestino.Text = txtNroDestino.Text + "8";
        }

        private void btnNro9_Click(object sender, EventArgs e)
        {
            txtNroDestino.Text = txtNroDestino.Text + "9";
        }

        private void btnAst_Click(object sender, EventArgs e)
        {
            txtNroDestino.Text = txtNroDestino.Text + "*";
        }

        private void btnNro0_Click(object sender, EventArgs e)
        {
            txtNroDestino.Text = txtNroDestino.Text + "0";
        }

        private void btnNum_Click(object sender, EventArgs e)
        {
            txtNroDestino.Text = txtNroDestino.Text + "#";
        }

        private void txtNroDestino_TextChanged(object sender, EventArgs e)
        {
            this.cmbFranja.Enabled = txtNroDestino.Text.StartsWith("#");
        }

        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            txtNroDestino.Text = "";
        }

        private void btnLlamar_Click(object sender, EventArgs e)
        {
            Random rndDuracion = new Random();

            //Llamada provincial
            if (txtNroDestino.Text.StartsWith("#") && Enum.TryParse<Provincial.Franja>(this.cmbFranja.SelectedItem.ToString(), out Provincial.Franja franja))//Comprueba si la llamada es provincial y si se eligio una franja de llamada valida en el combobox
            {
                this.llamada = new Provincial(txtNroOrigen.Text, franja, rndDuracion.Next(1, 50), txtNroDestino.Text);
                this.centralita = this.centralita + this.llamada;
            }
            //Llamada local
            else
            {
                this.llamada = new Local(txtNroOrigen.Text, rndDuracion.Next(1, 50), txtNroDestino.Text, 0.25f);
                this.centralita = this.centralita + this.llamada;
            }
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
