﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Punto_29
{
    class Jugador
    {
        int dni;
        string nombre;
        int partidosJugados;
        float promedioGoles;
        int totalGoles;

        public float GetPromedioGoles()
        {
            float promGoles = this.totalGoles / this.partidosJugados;

            this.promedioGoles = promGoles;
            return  this.promedioGoles;
        }

        private Jugador()
        {
            this.partidosJugados = 0;
            this.promedioGoles = 0;
            this.totalGoles = 0;
        }

        public Jugador(int dni, string nombre):this()
        {
            this.dni = dni;
            this.nombre = nombre;
        }

        public Jugador(int dni, string nombre, int totalGoles, int totalPartidos):this(dni, nombre)
        {
            this.totalGoles = totalGoles;
            this.partidosJugados = totalPartidos;
        }
        
        public string MostrarDatos()
        {
            StringBuilder datosJugador = new StringBuilder();

            datosJugador.AppendLine("DNI: " + this.dni);
            datosJugador.AppendLine("Nombre: " + this.nombre);
            datosJugador.AppendLine("Partidos jugados: " + this.partidosJugados);
            datosJugador.AppendLine("Total goles: " + this.totalGoles);
            datosJugador.AppendLine("Promedio goles: " + this.GetPromedioGoles());

            return datosJugador.ToString();
        }

        public static bool operator !=(Jugador j1, Jugador j2)
        {
            return !(j1 == j2);
        }

        public static bool operator ==(Jugador j1, Jugador j2)
        {
            return (j1.dni == j2.dni);
        }
    }
}
