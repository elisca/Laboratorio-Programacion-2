﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ejercicio_28
{
    public partial class Frm_Parser : Form
    {
        public Frm_Parser()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            Parser.TextoParser = this.rtbTexto.Text;
            MessageBox.Show(Parser.RankearPalabras(), "Ranking de palabras", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
