﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_28
{
    public static class Parser
    {
        static Dictionary<string, int> rankingPalabras = new Dictionary<string, int>();
        static string texto;
        static string[] listaPalabras;

        public static string TextoParser
        {
            set
            {
                if (value.Length > 0)
                {
                    Parser.texto = value;
                }
            }
        }

        public static string RankearPalabras()
        {
            List<KeyValuePair<string, int>> listaRanking = new List<KeyValuePair<string, int>>();
            StringBuilder datosRanking = new StringBuilder();
            texto = texto.Trim();
            listaPalabras = texto.Split(' ');

            for (int i = 0; i < listaPalabras.Length; i++)
            {
                if (!rankingPalabras.ContainsKey(listaPalabras[i]))
                {
                    rankingPalabras.Add(listaPalabras[i], 1);
                }
                else
                {
                    rankingPalabras[listaPalabras[i]]++;
                }
            }

            listaRanking = rankingPalabras.ToList();
            listaRanking.Sort((x, y) => x.Value.CompareTo(y.Value));
            listaRanking.Reverse();

            for (int i = 0; i <= 2; i++)
            {
                datosRanking.AppendLine("Palabra " + listaRanking.ElementAt(i).Key + ": " + listaRanking.ElementAt(i).Value);
            }

            return datosRanking.ToString();
        }
    }
}
