﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_31
{
    class Cliente
    {
        string nombre;
        int numero;

        public string Nombre
        {
            get => nombre;
            set => nombre = value;
        }

        public int Numero
        {
            get => numero;
        }
    }
}
