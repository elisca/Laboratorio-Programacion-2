﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IO
{
    class PuntoDat:Archivo, IArchivos<PuntoDat>
    {
        string contenido;

        public string Contenido { get => contenido; set => contenido = value; }

        public bool Guardar(string ruta, PuntoDat objeto)
        {
            return false;
        }

        public bool GuardarComo(string ruta, PuntoDat objeto)
        {
            return false;
        }

        public PuntoDat Leer(string ruta)
        {
            return null;
        }

        protected override bool ValidarArchivo(string ruta, bool validaExistencia)
        {
            return false;
        }
    }
}
