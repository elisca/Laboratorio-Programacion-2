﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IO
{
    class PuntoTxt:Archivo, IArchivos<string>
    {
        public bool Guardar(string ruta, string objeto)
        {
            return false;
        }

        public bool GuardarComo(string ruta, string objeto)
        {
            return false;
        }

        public string Leer(string ruta)
        {
            return null;
        }

        protected override bool ValidarArchivo(string ruta, bool validaExistencia)
        {
            return false;
        }
    }
}
