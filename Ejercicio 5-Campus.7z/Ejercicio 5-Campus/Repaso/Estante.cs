﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repaso
{
    public class Estante
    {
        Producto[] productos;
        int ubicacionEstante;

        private Estante(int capacidad)
        {
            productos = new Producto[capacidad];
        }

        public Estante(int capacidad, int ubicacion):this(capacidad)
        {
            this.ubicacionEstante = ubicacion;
        }

        public Producto[] GetProductos()
        {
            return this.productos;
        }

        public static string MostrarEstante(Estante e)
        {
            StringBuilder datosEstante = new StringBuilder();

            datosEstante.AppendLine("Estante:");

            foreach (Producto auxProd in e.productos)
            {
                if (!(auxProd is null))
                {
                    datosEstante.AppendLine("Producto:");
                    datosEstante.AppendLine("Cód. de barra: " + (string)auxProd);
                    datosEstante.AppendLine("Marca: " + auxProd.GetMarca());
                    datosEstante.AppendLine("Precio: $" + auxProd.GetPrecio() + "\n");
                }
            }

            return datosEstante.ToString();
        }

        public static bool operator !=(Estante e, Producto p)
        {
            return !(e==p);
        }

        public static Estante operator -(Estante e, Producto p)
        {
            for (int i = 0; i < e.productos.Count() - 1; i++)
            {
                if (e.productos[i] == p)
                {
                    e.productos[i] = null;
                }
            }
            return e;
        }

        public static bool operator +(Estante e, Producto p)
        {
            if (!(p is null) && e != p)
            {
                for (int i = 0; i < e.productos.Count(); i++)
                {
                    if (e.productos[i] is null)
                    {
                        e.productos[i] = p;
                        return true;
                    }
                }
            }
            return false;
        }

        public static bool operator ==(Estante e, Producto p)
        {
            foreach (Producto auxProd in e.productos)
            {
                if(!(auxProd is null) && !(p is null) && auxProd == p)
                {
                    return true;
                }
            }
            return false;
        }
    }
}
