﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Practica
{
    class Program
    {
        static void Main(string[] args)
        {
            int numValor;
            Objeto miObjeto = new Objeto();
            miObjeto.miEvento += MetodoManejador1;
            miObjeto.miEvento += MetodoManejador2;

            miObjeto.LlamadorDeEventos();
        }

        public static int MetodoManejador1(string valor)
        {
            int intValor;

            int.TryParse(valor, out intValor);
            return intValor;
        }

        public static int MetodoManejador2(string valor)
        {
            int intValor;

            int.TryParse(valor, out intValor);
            return intValor * 2;
        }
    }
}
