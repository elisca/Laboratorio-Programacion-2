﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Practica
{
    public class Objeto
    {
        public delegate int MiDelegado(string valor);

        public event MiDelegado miEvento;

        public Objeto()
        {
            //miEvento += MetodoManejador1;
            //miEvento += MetodoManejador2;
        }

        public void LlamadorDeEventos()
        {
            Console.WriteLine("HOLA: " + this.miEvento.Invoke("1"));
        }
    }
}
