﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Negocio
{
    public class Alimenticio:Producto
    {
        DateTime vencimiento;

        public Alimenticio(int idProd, string descripcion, DateTime fechaVencimiento):base(idProd, descripcion)
        {
            this.Vencimiento = fechaVencimiento;
        }

        public override int Id_prod
        {
            get
            {
                return base.Id_prod;
            }

            set
            {
                if (value >= 0)
                {
                    base.Id_prod = value;
                }
            }
        }

        public override string Descripcion
        {
            get
            {
                return base.Descripcion;
            }

            set
            {
                if (value.Length > 0)
                {
                    base.Descripcion = value;
                }
            }
        }

        public DateTime Vencimiento
        {
            get
            {
                return this.vencimiento;
            }

            set
            {
                this.vencimiento = value;
            }
        }
    }
}
