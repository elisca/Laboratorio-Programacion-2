﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Negocio
{
    public class Ferreteria:Producto
    {
        float peso;

        public Ferreteria(int idProd, string descripcion, float peso):base(idProd, descripcion)
        {
            this.Peso = peso;
        }

        public override int Id_prod
        {
            get
            {
                return base.Id_prod;
            }

            set
            {
                if (value >= 0)
                {
                    base.Id_prod = value;
                }
            }
        }

        public override string Descripcion
        {
            get
            {
                return base.Descripcion;
            }

            set
            {
                if (value.Length > 0)
                {
                    base.Descripcion = value;
                }
            }
        }

        public float Peso
        {
            get
            {
                return this.peso;
            }

            set
            {
                if (value > 0)
                {
                    this.peso = value;
                }
            }
        }
    }
}
