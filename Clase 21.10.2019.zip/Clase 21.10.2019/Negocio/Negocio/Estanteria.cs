﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Negocio
{
    public class Estanteria<T> where T:Producto
    {
        int tamano;
        Producto[] productos;

        public Estanteria(int tamano)
        {
            this.Tamano = tamano;
            this.Productos = new Producto[this.Tamano];
        }

        public int Tamano
        {
            get
            {
                return this.tamano;
            }

            set
            {
                if (value > 0)
                {
                    this.tamano = value;
                }
            }
        }

        public Producto[] Productos
        {
            get
            {
                return this.productos;
            }

            set
            {
                if (value != null)
                {
                    this.productos = value;
                }
            }
        }

        public static bool operator +(Estanteria<T> estanteria, T producto)
        {
            if (estanteria != producto && estanteria.Productos.Length < estanteria.Tamano)
            {
                estanteria.Productos[estanteria.Productos.Length] = producto;
                return true;
            }
            else
            {
                return false;
            }
        }

        public static bool operator -(Estanteria<T> estanteria, T producto)
        {
            if (estanteria == producto)
            {
                for (int i = 0; i < estanteria.Tamano; i++)
                {
                    if (estanteria.Productos[i].Id_prod == producto.Id_prod)
                    {
                        estanteria.Productos[i] = null;
                        return true;
                    }
                }
            }
            return false;
        }

        public static bool operator ==(Estanteria<T> estanteria, T producto)
        {
            foreach (T auxProducto in estanteria.Productos)
            {
                if (auxProducto.Id_prod == producto.Id_prod)
                {
                    return true;
                }
            }
            return false;
        }

        public static bool operator !=(Estanteria<T> estanteria, T producto)
        {
            return !(estanteria == producto);
        }
    }
}
