﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Negocio
{
    public abstract class Producto
    {
        int id_prod;
        string descripcion;

        public Producto(int idProd, string descripcion)
        {
            this.Id_prod = idProd;
            this.Descripcion = descripcion;
        }

        public virtual int Id_prod
        {
            get
            {
                return this.id_prod;
            }

            set
            {
                this.id_prod = value;
            }
        }

        public virtual string Descripcion
        {
            get
            {
                return this.descripcion;
            }

            set
            {
                this.descripcion = value;
            }
        }
    }
}
