﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Negocio;

namespace ChinoApu
{
    class Program
    {
        static void Main(string[] args)
        {
            Estanteria<Alimenticio> chinoApuAlimenticio = new Estanteria<Alimenticio>(2);
            Estanteria<Ferreteria> chinoApuFerreteria = new Estanteria<Ferreteria>(5);

            Alimenticio comida00 = new Alimenticio(10, "Lata de tomates", DateTime.Today);
            Alimenticio comida01 = new Alimenticio(11, "Paquete de chizitos", DateTime.Today);
            Alimenticio comida02 = new Alimenticio(12, "Botella de Coca-Cola", DateTime.Today);
            Alimenticio comida03 = new Alimenticio(13, "Pollo descongelado", DateTime.Today);
            Alimenticio comida04 = new Alimenticio(14, "Jamon cocido", DateTime.Today);

            Ferreteria herramienta00 = new Ferreteria(20, "Pinza universal", 2);
            Ferreteria herramienta01 = new Ferreteria(21, "Pinza de punta", 1);
            Ferreteria herramienta02 = new Ferreteria(22, "Morsa", 10);
            Ferreteria herramienta03 = new Ferreteria(23, "Tester universal", 2);
            Ferreteria herramienta04 = new Ferreteria(24, "Pinza universal", 2);
            Ferreteria herramienta05 = new Ferreteria(25, "Pinza universal", 2);
            Ferreteria herramienta06 = new Ferreteria(26, "Pinza universal", 2);
            Ferreteria herramienta07 = new Ferreteria(27, "Pinza universal", 2);
            Ferreteria herramienta08 = new Ferreteria(28, "Pinza universal", 2);
            Ferreteria herramienta09 = new Ferreteria(29, "Pinza universal", 2);

        }
    }
}
