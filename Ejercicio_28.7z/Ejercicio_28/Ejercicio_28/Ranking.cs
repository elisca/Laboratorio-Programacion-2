﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_28
{
    public class Ranking
    {
        public Dictionary<string, int> CalcularRanking(string texto)
        {
            Dictionary<string, int> rankingPalabras = new Dictionary<string, int>();
            string textoAuxiliar = texto;
            string[] palabraAuxiliar;

            textoAuxiliar = textoAuxiliar.Trim();

            palabraAuxiliar = texto.Split(' ');

            return null;

        }
    }
}
